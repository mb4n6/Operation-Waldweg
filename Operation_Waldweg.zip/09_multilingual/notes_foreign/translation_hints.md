# Mehrsprachige Inhalte – Hinweise

Enthaltene Sprachen:
- Deutsch
- Englisch
- Türkisch
- Russisch

Didaktische Ziele:
- Sprache erkennen
- transkribieren
- übersetzen
- semantisch in den Gesamtkontext einordnen

Wichtiger Hinweis:
Nicht jede fremdsprachige Nachricht ist ermittlungsrelevant. Relevanz muss begründet werden.
