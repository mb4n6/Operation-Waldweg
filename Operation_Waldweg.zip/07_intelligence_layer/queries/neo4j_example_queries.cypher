// 1. Personen mit hohem Prioritätswert und Ortsnähe
MATCH (p:Person)-[:INVOLVED_IN]->(e:Event)-[:OCCURRED_AT|POINTS_TO]->(l:Location)
WHERE l.label CONTAINS 'Wald' OR l.label CONTAINS 'Waldparkplatz'
RETURN p.label, collect(distinct e.label), collect(distinct l.label);

// 2. Ereigniskette des Opfers im kritischen Fenster
MATCH (p:Person {label:'Anna Reuter'})-[:INVOLVED_IN]->(e:Event)
WHERE e.timestamp >= '2026-01-25T07:30:00' AND e.timestamp <= '2026-01-25T08:00:00'
RETURN e.label, e.timestamp
ORDER BY e.timestamp;

// 3. Korroborierende Quellen für Jonas
MATCH (p:Person {label:'Jonas Brehm'})-[:INVOLVED_IN]->(e:Event)
RETURN e.label, e.source, e.timestamp
ORDER BY e.timestamp;
