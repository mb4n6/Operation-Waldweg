-- Beispiel: priorisierte Person aus Scores
SELECT person, overall_priority
FROM person_priority_scores
ORDER BY overall_priority DESC;

-- Beispiel: Ereignisse nach Confidence
SELECT timestamp, summary, confidence
FROM consolidated_timeline
ORDER BY timestamp;
